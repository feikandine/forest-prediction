## Classification des catégories de forêts à partir de données cartographiques

# Description du projet

Ce projet a pour objectif d'utiliser des données cartographiques pour classer différentes catégories de forêts. En analysant les données, en créant des features pertinentes et en entraînant plusieurs modèles de machine learning, nous cherchons à atteindre une précision optimale sur le jeu de test, tout en évitant le surapprentissage.

# Structure du projet

project/
├── README.md                       # Documentation du projet
├── environment.yml                 # Fichier pour recréer l'environnement
├── data/                           # Données brutes
│   ├── train.csv                   # Jeu d'entraînement
│   ├── test.csv                    # Jeu de test (dernier jour)
│   └── covtype.info                # Documentation des données
│
├── notebook/                       # Analyses exploratoires
│   └── EDA.ipynb                   # Exploration et analyse des données
│
├── scripts/                        # Scripts principaux
│   ├── preprocessing_feature_engineering.py  # Prétraitement et création des features
│   ├── model_selection.py                    # Sélection et évaluation des modèles
│   └── predict.py                             # Prédictions sur le jeu de test
│
└── results/                        # Résultats du projet
    ├── plots/                      # Graphiques
    ├── test_predictions.csv        # Prédictions sur le jeu de test final
    └── best_model.pkl              # Modèle sauvegardé


## Étapes du projet

1. Analyse exploratoire des données (EDA)

Exploration des données dans le notebook EDA.ipynb.
Création de nouvelles features pertinentes pour améliorer les performances des modèles

2. Prétraitement et création des features

Implémenté dans preprocessing_feature_engineering.py.
Normalisation ou standardisation des données en fonction des modèles.

3. Sélection des modèles

Validation croisée avec 5 folds pour garantir la généralisation.
Grid search effectué sur les modèles suivants :
Gradient Boosting
KNN
Random Forest
SVM
Régression Logistique

Critères de sélection du modèle :

Précision sur le train < 0,98 (éviter le surapprentissage).
Précision sur le test > 0,65 (objectif final).
Meilleur modèle sauvegardé dans best_model.pkl.

4. Évaluation du meilleur modèle

Matrice de confusion (confusion matrix) pour évaluer les erreurs de classification.
Courbe d'apprentissage pour analyser la performance en fonction de la taille des données.

5. Prédictions finales

Prédictions réalisées sur test.csv avec le meilleur modèle.
Résultats sauvegardés dans test_predictions.csv.
Résultats et scores
Précision sur le jeu d'entraînement (train) : xx.xx%
Précision sur le jeu de validation (cross-validation) : xx.xx%
Précision sur le jeu de test final : xx.xx%
Matrice de confusion du meilleur modèle
True label	Class 1	Class 2	...
Predicted	...	...	...
Courbe d'apprentissage
Graphique disponible dans le dossier results/plots/.

## Installation et exécution

Créer un environnement à partir de environment.yml :

-conda env create -f environment.yml
-conda activate forest-classification

Exécuter les étapes :
Prétraitement et création des features :

-python scripts/preprocessing_feature_engineering.py

Sélection et entraînement des modèles :

-python scripts/model_selection.py

Prédictions finales sur test.csv :

-python scripts/predict.py

## Améliorations potentielles

Ajouter des features spécifiques aux classes mal classées identifiées via la matrice de confusion.
Tester d'autres modèles ou techniques d'ensemble (e.g., stacking).

## Scores
-RandomForest : 0.9316889500901693
-GradientBoosting : 0.937070716400171
-KNN : 0.9259526175209191
-LogisticRegression : 0.791276015597619
-SVM : 

## Auteur
-Féikandine
-jemmanue
